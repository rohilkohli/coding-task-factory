"""
From https://click.palletsprojects.com/en/stable/options/#callbacks-and-eager-options.
"""

from typing import assert_type

import click


@click.command()
@click.version_option("0.1")
def hello() -> None:
    click.echo("Hello World!")


assert_type(hello, click.Command)
