Put your regression test in this directory as `test_regression.py` (pytest).

During grading the file is copied into `/app/tests/`, so the fixtures defined
in `tests/conftest.py` (for example `runner`) are available to it.
